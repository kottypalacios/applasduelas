export const environment = {
    production: false,
    uri: 'http://localhost:3000/'
};
