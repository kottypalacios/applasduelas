export const environment = {
  production: true,
  uri: 'http://localhost:3000/'
};
